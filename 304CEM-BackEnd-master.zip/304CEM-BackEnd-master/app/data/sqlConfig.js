exports.sqlConfig = {
  host: 'remotemysql.com',
  user: 'JMWRQicCbQ',
  password: 'SfXjRWCeZl',
  database: 'JMWRQicCbQ'
};
